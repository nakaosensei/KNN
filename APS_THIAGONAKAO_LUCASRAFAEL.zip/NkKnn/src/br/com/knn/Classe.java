/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.knn;

import java.util.List;

/**
 *
 * @author Thiago Nakao <nakaosensei@gmail.com>
 */
public class Classe {
    public String nome;
    public int posMatConfusao;
    
    public Classe(String n){
        this.nome=n;
        
    }
    public Classe(){
        this.nome="";
    }
    
    public static List<Classe> add(List<Classe> l,Classe c){
        int achou = 0;
        for(Classe classe:l){
            if(classe.nome.equals(c.nome)){
                achou = 1;
            }
        }
        if(achou==0){
            if(l.isEmpty()){
                c.posMatConfusao=0;
            }else{
                c.posMatConfusao=l.get(l.size()-1).posMatConfusao+1;
            }
            l.add(c);            
        }
        return l;
    }
    
    public void print(){
        System.out.println("Classe "+this.nome +" id:"+this.posMatConfusao);
    }
}
