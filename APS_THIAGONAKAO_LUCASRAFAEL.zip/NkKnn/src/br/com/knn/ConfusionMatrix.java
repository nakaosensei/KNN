/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.knn;

import br.com.util.File;
import java.math.BigDecimal;
import java.util.List;

/**
 *
 * @author Thiago Nakao <nakaosensei@gmail.com>
 */
public class ConfusionMatrix {
    public BigDecimal matrix[][];
    public List<Classe> classes;
    
    public ConfusionMatrix(List<Classe> cls){
        this.classes=cls;        
        matrix = new BigDecimal[cls.size()][cls.size()];
        for(int i = 0;i<cls.size();i++){
            for(int j = 0;j<cls.size();j++){
                matrix[i][j]=BigDecimal.ZERO;
            }
        }  
    }
    
    public void escreverMatrizConfusao(){
        String out = "";
        for(int i = 0;i<this.classes.size();i++){
            for(int j = 0;j<this.classes.size();j++){
                out+=this.matrix[i][j].toString()+" ";
            }
            out+="\n";
        }
        File f = new File();
        f.escreverArquivo("src/br/com/out/confusionMatrix.txt", out);
    } 
 }
