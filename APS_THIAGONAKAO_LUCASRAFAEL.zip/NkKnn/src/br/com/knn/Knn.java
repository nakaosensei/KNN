package br.com.knn;

import br.com.util.File;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author Thiago Nakao <nakaosensei@gmail.com>
 */
public class Knn {
    public List<Instance> treino = new ArrayList<>();
    public List<Instance> teste = new ArrayList<>();
    public List<Classe> classes = new ArrayList<>();
    public ConfusionMatrix cm;
    public int k;
    public int qtdeAcertos = 0;
    
    
    public void treinar(String filePath){
        File f = new File();
        List<String> lTreinoStr = f.convertFileToStringList(filePath);        
        for(String s:lTreinoStr){            
            treino.add(new Instance(s.split(" ")));                 
        }        
    }    
    
    public void setarConjuntoTeste(String filePath){
        File f = new File();
        List<String> lTreinoStr = f.convertFileToStringList(filePath);        
        for(String s:lTreinoStr){            
            teste.add(new Instance(s.split(" ")));                 
        }
    }
    
    public void executar(int k){
        popularClassesDistintas();//Carrega o array de classes
        cm = new ConfusionMatrix(classes);
        List<DistanceUtil> distances = new ArrayList<>();
        DistanceUtil d;
        for(Instance tst:teste){
            for(Instance tr:treino){
                d = new DistanceUtil();
                d.alvo=tr;
                d.distance =(Instance.euclidianDistanceCalc(tst, tr));
                distances.add(d);
            }
            Collections.sort(distances);
            Classe r = doVotoMajoritario(distances, k);
            if(r.nome.equals(tst.classe.nome)){
                this.qtdeAcertos++;
            }            
            cm.matrix[tst.classe.posMatConfusao][r.posMatConfusao]=cm.matrix[tst.classe.posMatConfusao][r.posMatConfusao].add(BigDecimal.ONE);
            distances = new ArrayList<>();
        }        
    }
    
    public void executarSingleton(int k, Instance tst){
        popularClassesDistintas();//Carrega o array de classes
        cm = new ConfusionMatrix(classes);
        List<DistanceUtil> distances = new ArrayList<>();
        DistanceUtil d;
        for(Instance tr:treino){
            d = new DistanceUtil();
            d.alvo=tr;
            d.distance =(Instance.euclidianDistanceCalc(tst, tr));
            distances.add(d);
        }
        Collections.sort(distances);
        Classe r = doVotoMajoritario(distances, k);
        System.out.println(r.nome);        
    }
    
    public void popularClassesDistintas(){
        for(Instance c:treino){
            classes = Classe.add(classes, c.classe);
        }
        for(Instance c:teste){
            classes = Classe.add(classes, c.classe);
        }        
        for(Instance c:teste){
            for(Classe classe:classes){
                if(c.classe.nome.equals(classe.nome)){
                    c.classe.posMatConfusao=classe.posMatConfusao;
                }
            }
        }
        for(Instance c:treino){
            for(Classe classe:classes){
                if(c.classe.nome.equals(classe.nome)){
                    c.classe.posMatConfusao=classe.posMatConfusao;
                }
            }
        }
    }
    
    public Classe doVotoMajoritario(List<DistanceUtil> l,int k){
        MajoritarioListUtil mlu = new MajoritarioListUtil();
        MajoritarioUtil mu;
        for(int i = 0;i<k;i++){
            mu = new MajoritarioUtil();
            mu.classe=l.get(i).alvo.classe;
            mlu.add(mu);
        }
        Collections.reverse(mlu.lista);
        return mlu.lista.get(0).classe;
    }
    
    public static List<Instance> normalizar(List<Instance> l){
        MinMax mm[] = MinMax.findMinMaxArray(l);
        BigDecimal tmp;
        List<Instance> newInst = new ArrayList<>();
        Instance tInst;
        for(int j = 0;j<l.get(0).caracteristicas.size();j++){
            for(int i = 0;i<l.size();i++){
                tmp = l.get(i).caracteristicas.get(j);
                tmp = (tmp.subtract(mm[j].min));
                l.get(i).caracteristicas.set(j  , mm[j].max.equals(mm[j].min)? BigDecimal.ZERO:  tmp.divide(mm[j].max.subtract(mm[j].min),RoundingMode.DOWN));               
            }
        }        
        return l;        
    }


    
    
    private static class DistanceUtil implements Comparable<DistanceUtil>{
        public BigDecimal distance;
        public Instance alvo;

        @Override
        public int compareTo(DistanceUtil o) {
            return this.distance.compareTo(o.distance);
        }
    }
    
    private static class MajoritarioUtil implements Comparable<MajoritarioUtil>{
        public Classe classe;
        public int votos;

        @Override
        public int compareTo(MajoritarioUtil o) {
           return Integer.compare(this.votos, o.votos);
        }
    }
    
    private static class MajoritarioListUtil{
        public List<MajoritarioUtil> lista = new ArrayList<>();
        
        public void add(MajoritarioUtil m){
            int achou = 0;
            for(MajoritarioUtil mu:lista){
                if(mu.classe.nome.equals(m.classe.nome)){
                    achou = 1;
                    mu.votos++;
                    break;
                }
            }
            if(achou==0){
                m.votos++;
                lista.add(m);
            }
        }

        
    }
}
