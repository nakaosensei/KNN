/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.knn;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

/**
 *
 * @author Thiago Nakao <nakaosensei@gmail.com>
 */
public class MinMax {
    public int posCaracteristica;
    public BigDecimal min;
    public BigDecimal max;
    
    public static MinMax[] findMinMaxArray(List<Instance> instances){
        MinMax minMax[] = new MinMax[instances.get(0).caracteristicas.size()];
        BigDecimal min = new BigDecimal(BigInteger.ZERO);
        BigDecimal max = new BigDecimal(BigInteger.ZERO);
        int i=0;
        
        for(int j = 0;j<instances.get(0).caracteristicas.size();j++){            
            min = instances.get(0).caracteristicas.get(j);
            max = instances.get(0).caracteristicas.get(j);
                      
            for(i = 0; i<instances.size();i++){
                if(min.compareTo(instances.get(i).caracteristicas.get(j))==1){//Min>val
                    min = instances.get(i).caracteristicas.get(j);                    
                }
                if(max.compareTo(instances.get(i).caracteristicas.get(j))==-1){//Max<val
                    max = instances.get(i).caracteristicas.get(j);                    
                }
            }            
            MinMax minMx = new MinMax();
            
            minMx.min = min;
            minMx.max = max;            
            minMx.posCaracteristica=j;
            minMax[j] = minMx;            
        }   
        return minMax;
    }
}
