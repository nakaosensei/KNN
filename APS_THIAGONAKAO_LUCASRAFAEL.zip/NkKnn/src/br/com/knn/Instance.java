/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.knn;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Thiago Nakao <nakaosensei@gmail.com>
 * A classe instance é a estrutura de dados para armazenar cada classe
 * e a sua lista de caracteristicas
 */
public class Instance {
    public Classe classe = new Classe();
    public List<BigDecimal> caracteristicas = new ArrayList<>();
    
    public Instance(String[] caracteristicas){
        BigDecimal tmp;        
        for (int i = 0;i<caracteristicas.length-1;i++) {
            if (!caracteristicas[i].isEmpty()) {
                this.caracteristicas.add(new BigDecimal(caracteristicas[i]));
            }
        }
        this.classe.nome=caracteristicas[caracteristicas.length-1];
    }      
        
    public void print(){
        System.out.println("\nClasse: "+this.classe.nome);
        for(BigDecimal d:this.caracteristicas){
            System.out.print(d.toString()+" ");
        }
    }
    
    public static BigDecimal euclidianDistanceCalc(Instance a,Instance b){
        BigDecimal euclDist = new BigDecimal("0");
        for(int i = 0; i<a.caracteristicas.size();i++){
            euclDist = euclDist.add((a.caracteristicas.get(i).subtract(b.caracteristicas.get(i) )).pow(2));
        }
        euclDist = Instance.sqrt(euclDist);
        return euclDist;
    }
    
    public static BigDecimal sqrt(BigDecimal x) {
	return BigDecimal.valueOf(StrictMath.sqrt(x.doubleValue()));
    }
}
