package br.com.util;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author nakao
 */
public class File {
    private FileReader arq;
    private BufferedReader buff;
    
    public String convertFileToString(String path){
        String file="";        
        try {
            arq = new FileReader (path);
            buff = new BufferedReader(arq);
            while (buff.ready()){
                file+=(buff.readLine())+"\n";                
            }
            buff.close();
            return file;
        }catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao abrir arquivo");
            return file;
        }        
    }
    
    public List<String> convertFileToStringList(String path){
        List<String> out = new ArrayList<>();
        try {
            arq = new FileReader (path);
            buff = new BufferedReader(arq);
            while (buff.ready()){
                out.add(buff.readLine());                
            }
            buff.close();
            return out;
        }catch (Exception ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Erro ao abrir arquivo");
            return out;
        }        
    }
    
    public void escreverArquivo(String path,String texto){
        try{
            FileWriter f = new FileWriter(path);
            PrintWriter gravarArq = new PrintWriter(f);
            gravarArq.print(texto);
            f.close();
        }catch(Exception e){
            System.out.println("Erro ao gerar arquivo");
            e.printStackTrace();
        }
    }
}
