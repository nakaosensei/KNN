package br.com.run;


import br.com.knn.Knn;

/**
 * @author Thiago Nakao <nakaosensei@gmail.com>
 */
public class Main {
    public static void main(String[] args) {
        Knn knn = new Knn();        
        knn.treinar("src/br/com/files/base2/training.txt");
        knn.treino = Knn.normalizar(knn.treino);
        knn.setarConjuntoTeste("src/br/com/files/base2/testing.txt");
        knn.teste = Knn.normalizar(knn.teste);
        knn.popularClassesDistintas();                       
        knn.executar(19);
        System.out.println("Accuracy:"+ ((double)knn.qtdeAcertos/knn.teste.size())*100);
        knn.cm.escreverMatrizConfusao();        
    }
}
